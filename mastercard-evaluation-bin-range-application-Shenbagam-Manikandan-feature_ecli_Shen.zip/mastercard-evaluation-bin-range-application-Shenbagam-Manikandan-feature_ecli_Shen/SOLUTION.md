Environment Overview:

Java Version : 11.0
IDE          : Eclipse 2019-12 (4.14.0)

Problem faced while running the master code:
--------------------------------------------
ObjectMapper and EventManager classes were not mocked initially so i have added mockito-core 2.22.0 dependency to resolve the issue in my local machine.

PART 1:
======

Problem:
========
        The existing test case was validating the given BIN range only. If the BIN range is empty it was not validating it.
        
Solution:
=========
        Added the empty check in CachingBinRangeServiceTest.java class to handle the test case.
        

PART 2:
======

Approach for implementing the CRUD Operations in BinRangeInfoCacheController.java: 
        
Considering H2 database for local testing may take configuration time, have created a temporary list of data which is given in the sample input JSON file.

The current implementation only adds the reference number in the above, assuming that the other BIN range details can be added in the real time with the same implementation approach.

Example:
  {
    "ref": "2A480C8A-83CA-4BB7-95B7-F19CEC97B3FD",  -- Currently added only this field.
    "start": "4263000000000000",
    "end": "4263999999999999",
    "bankName": "AIB",
    "currencyCode": "EUR"
  },

Implemented adequate testcases to validate entire CRUD functionalities. 

Input Format:
============

Create:
-------
End Point: https://localhost:8080/binRangeInfoCache/create

Request Body:
{
    "ref": "2A480C8A-83CA-4BB7-95B7-F19CEC97B3FD",  -- Currently added only this field.
    "start": "4263000000000000",
    "end": "4263999999999999",
    "bankName": "AIB",
    "currencyCode": "EUR"
  }
  
Update:
------

Endpoint: https://localhost:8080/binRangeInfoCache/update/2A480C8A-83CA-4BB7-95B7-F19CEC97B3FD

Request Body:
{
    "ref": "2A480C8A-83CA-4BB7-95B7-F19CEC97B3FD",  -- Currently added only this field.
    "start": "4263000000000000",
    "end": "4263999999999999",
    "bankName": "AIB",
    "currencyCode": "EUR"
  }
  
Delete:
------
Endpoint: https://localhost:8080/binRangeInfoCache/delete/2A480C8A-83CA-4BB7-95B7-F19CEC97B3FD

PART 3:
======

Based on the requirement given in AuditSubscriber.handleEvent() added a functionality that will give the current time stamp in "MMM dd,yyyy HH:mm" format in AuditEvent file and logged the event in AuditSubscriber.java.

currently i have hard coded the values of Before and after status while calling the audit event function. there might be a better way to handle this at run time.

present output of the implementation in the console log is
----------------------------------------------------------

022-02-08 14:03:58.441  INFO 512310 --- [           main] c.m.e.b.r.e.subscribers.AuditSubscriber  : createdAt=Tue Feb 08 14:03:58 IST 2022, before=created, after=
2022-02-08 14:03:58.447  INFO 512310 --- [           main] o.s.b.t.m.w.SpringBootMockServletContext : Initializing Spring FrameworkServlet ''
2022-02-08 14:03:58.447  INFO 512310 --- [           main] o.s.t.web.servlet.TestDispatcherServlet  : FrameworkServlet '': initialization started
2022-02-08 14:03:58.450  INFO 512310 --- [           main] o.s.t.web.servlet.TestDispatcherServlet  : FrameworkServlet '': initialization completed in 3 ms
2022-02-08 14:03:58.454  INFO 512310 --- [           main] c.m.e.b.r.e.subscribers.AuditSubscriber  : createdAt=Tue Feb 08 14:03:58 IST 2022, before=updated, after=created


output in audit-log.txt file is
-------------------------------
createdAt={Tue Feb 08 13:37:10 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 13:37:10 IST 2022}, before={}, after={created}
createdAt={Tue Feb 08 13:37:10 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 13:38:14 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 13:38:14 IST 2022}, before={}, after={created}
createdAt={Tue Feb 08 13:38:14 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 13:38:36 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 14:03:58 IST 2022}, before={created}, after={updated}
createdAt={Tue Feb 08 14:03:58 IST 2022}, before={}, after={created}
createdAt={Tue Feb 08 14:03:58 IST 2022}, before={created}, after={updated}
 